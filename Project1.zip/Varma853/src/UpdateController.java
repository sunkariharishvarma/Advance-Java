import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class UpdateController extends HttpServlet
{


	public void service(HttpServletRequest req,HttpServletResponse res) throws IOException
	{
		PrintWriter out=res.getWriter();
		Connection con=null;
		String name=req.getParameter("t1");
		String pwd=req.getParameter("t2");
		String email=req.getParameter("t3");
		long mobile=Long.parseLong(req.getParameter("t4"));
		String city=req.getParameter("t5");
		int i=0;
		try {
				Class.forName("org.h2.Driver");
				con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/hari","sa","sa");
		Statement stmt=con.createStatement();
		
	i=stmt.executeUpdate("update user1 set pwd='"+pwd+"',email='"+email+"',mobile='"+mobile+"',Address='"+city+"' where name='"+name+"'");
	System.out.println(i);	
	if(i>0)
		{
			out.print("updated successfully");
		}
		else
		{
			out.print("Update fail");
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
