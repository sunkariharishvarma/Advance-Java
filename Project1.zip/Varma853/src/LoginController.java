import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class LoginController extends HttpServlet
{

	public void service(HttpServletRequest req,HttpServletResponse res) throws IOException
		{
		PrintWriter out=res.getWriter();
		Connection con=null;
		String uname=req.getParameter("t1");
		String pwd=req.getParameter("t2");
		ResultSet rs=null;
		try {
			Class.forName("org.h2.Driver");
			con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/hari","sa","sa");
		
			Statement stmt=con.createStatement();
		rs=stmt.executeQuery("select name,pwd from user1 where name='"+uname+"' and pwd='"+pwd+"'");
		if(rs.next())
		{
			RequestDispatcher rd=req.getRequestDispatcher("welcome.html");
			rd.forward(req, res);
			
		}
		else
		{
			RequestDispatcher rd=req.getRequestDispatcher("login.html");
			rd.include(req, res);
			out.print("<center>Invalid username /password");
			
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

}
