package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import model.Cart;
import model.Login;
import model.Order;
import model.Product;

public class Dao
{
	static Connection con=null;
	public static Connection getconnectionObject()
	{
		try {
			Class.forName("org.h2.Driver");
			con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/varma","sa","sa");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return con;	
	}
	public boolean login(Login l)
	{

		boolean b=false;
		ResultSet rs=null;
		con=Dao.getconnectionObject();
		try {
		Statement s=con.createStatement();
		rs=s.executeQuery("select name,pwd from admin where name='"+l.getUname()+"' and pwd='"+l.getPwd()+"'");
		if(rs.next())
		{
			b=true;
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public boolean addProduct(Product p)
	{
		int i=0;
		boolean b=false;
		con=Dao.getconnectionObject();
		try {
			PreparedStatement ps=con.prepareStatement("insert into stock values(?,?,?,?,?,?,?,?)");
			ps.setString(1, p.getPid());
			ps.setString(2, p.getPname().toLowerCase());
			ps.setDouble(3, p.getPprice());
			ps.setInt(4, p.getPqty());
			ps.setString(5, p.getFilename());
			ps.setString(6, p.getTdate());
			ps.setString(7, p.getCtype());
			ps.setString(8, p.getPinfo());
			
			i=ps.executeUpdate();
			if(i>0)
				b=true;
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public ArrayList<Product> searchProduct(Product p) 
	{
		ArrayList<Product> al=new ArrayList<Product>();
		ResultSet rs=null;
	    con=Dao.getconnectionObject();
		try {
			
			Statement stmt=con.createStatement();
		
			rs=stmt.executeQuery("select pid,pname,pprice,filename,productinfo from stock where pname like '%"+p.getPname().toLowerCase()+"%'");
			while(rs.next())
			{
				Product p1=new Product();
				p1.setPid(rs.getString(1));
				p1.setPname(rs.getString(2));
				p1.setPprice(rs.getDouble(3));
				p1.setFilename(rs.getString(4));
				p1.setPinfo(rs.getString(5));
				al.add(p1);		
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return al;	
	}
	
	public boolean customerLogin(Login l) 
	{
		boolean b=false;
		con=Dao.getconnectionObject();
		ResultSet rs=null;
		try {
			Statement s=con.createStatement();
			rs=s.executeQuery("select uname,pwd from customer");
			if(rs.next())
				b=true;
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return b;
	}
	public Product productInfoByPid(Product p1)
	{
		Product p=new Product();
		ResultSet rs=null;
		con=Dao.getconnectionObject();
		try {
			Statement s=con.createStatement();
			rs=s.executeQuery("select *from stock where pid='"+p1.getPid()+"'");
			if(rs.next())
			{
				p.setPid(rs.getString(1));
				p.setPname(rs.getString(2));
				p.setPprice(rs.getDouble(3));
				p.setPqty(rs.getInt(4));
				p.setFilename(rs.getString(5));
				p.setPinfo(rs.getString(8));
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return p;
		
	}

	public String addTOCart(Product p) 
	{
		String pid=null;
		int i=0;
		con=Dao.getconnectionObject();
		try 
		{
			PreparedStatement pstmt=con.prepareStatement("insert into cart values(?,?,?,?)");
			pstmt.setString(1, p.getPid());
			pstmt.setString(2, p.getPname());
			pstmt.setDouble(3, p.getPprice());
			pstmt.setDouble(4, p.getPprice()*p.getPqty());
			i=pstmt.executeUpdate();
			if(i>0)
				pid=p.getPid();
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return pid;
		
	}
	public ArrayList<Cart> viewcart()
	{
		ArrayList<Cart> al=new ArrayList<Cart>();
		ResultSet rs=null;
		con=Dao.getconnectionObject();
		try {
			Statement s=con.createStatement();
			rs=s.executeQuery("select *from cart");
			while(rs.next())
			{
				Cart c=new Cart();
				c.setPid(rs.getString(1));
				c.setPname(rs.getString(2));
				c.setPrice(rs.getDouble(3));
				c.setTprice(rs.getDouble(4));
				al.add(c);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return al;
	}
	public int payBill(Order o)
	{
		
		int i=0;
		con=Dao.getconnectionObject();
		try {
		PreparedStatement pstmt=con.prepareStatement("insert into order1(oamt) values(?)");
		pstmt.setDouble(1, o.getOamt());
		i=pstmt.executeUpdate();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return i;
	}

}

