package controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import dao.Dao;
import model.Login;
import model.Product;
@WebServlet(urlPatterns= {"/","/reqadminlogin","/adminlogin","/reqaddproduct"})
public class AdminController extends HttpServlet 
{
	  private final String upload_dir = "D://cloud";

	public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
	{

		Login l=new Login();
		String path=req.getServletPath();
		
		PrintWriter out=res.getWriter();
		if(path.equals("/adminlogin")) 
		{
			
		l.setUname(req.getParameter("t1"));
		l.setPwd(req.getParameter("t2"));
	
		System.out.println(l.getUname());
		
		boolean b=new Dao().login(l);
		if(b)
		{
			RequestDispatcher rd=req.getRequestDispatcher("view/adminhome.jsp");
			rd.forward(req,res);
		}
		else
		{
			out.print("Invalid user");
		}
		}
		else if(path.equals("/reqaddproduct"))
  	  {
  		  
  		Product p=new Product();  
  	  
		if(ServletFileUpload.isMultipartContent(req))
		{
	        try {
               List<FileItem> multiparts = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(req);
                     
               for(FileItem item : multiparts)
               {

                   if(!item.isFormField())
                   {
                       String name = new File(item.getName()).getName();
                       item.write( new File(upload_dir + File.separator + name));
                       p.setFilename(name);
                   }
                   else
                   {
                   	if(item.getFieldName().equals("pid"))
                   	{
                   		p.setPid(item.getString());
                   	}
                   	else if(item.getFieldName().equals("pname"))
                   	{
                           p.setPname(item.getString());
                   	}
                   	else if(item.getFieldName().equals("pprice"))
                   	{
                   		p.setPprice(Double.parseDouble(item.getString()));
                   	}
                  	else if(item.getFieldName().equals("pqty"))
                   	{
                   		p.setPqty(Integer.parseInt(item.getString()));
                   	}
                  	else if(item.getFieldName().equals("tdate"))
                   	{
                   		p.setTdate(item.getString());
                   	}
                  	else if(item.getFieldName().equals("ctype"))
                   	{
                   		p.setCtype(item.getString());
                   	}
                  	else if(item.getFieldName().equals("productinfo"))
                   	{
                   		p.setPinfo(item.getString());
                   	}
                   }
               }
               
          boolean  b=new Dao().addProduct(p); 
            if(b)
            {
          	  RequestDispatcher rd=req.getRequestDispatcher("view/addproduct.jsp");
          	  rd.include(req, res);
          	  out.print(p.getPid()+" details added successfully");
            }
               
           } 
	        catch (Exception ex)
	        {
              System.out.println(ex);
           } 
		}
  	  }
}

			
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		String path=req.getServletPath();
		if(path.equals("/"))
		{
		RequestDispatcher rd=req.getRequestDispatcher("view/index.jsp");
		rd.forward(req,res);
		}
		if(path.equals("/reqadminlogin"))
		{
		RequestDispatcher rd=req.getRequestDispatcher("view/adminlogin.jsp");
		rd.forward(req,res);
		}
		if(path.equals("/reqaddproduct"))
		{
		RequestDispatcher rd=req.getRequestDispatcher("view/addproduct.jsp");
		rd.forward(req,res);
		}
	}

}
