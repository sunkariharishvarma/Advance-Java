package controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import dao.Dao;
import model.Cart;
import model.Login;
import model.Order;
import model.Product;
@WebServlet(urlPatterns= {"/reqsearchproduct","/reqsorting","/reqcustomerlogin","/reqaddtocart","/addtocart1","/reqviewcart","/reqpaybill"})
public class CustomerController extends HttpServlet
{
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		Product p=new Product();
		ArrayList<Product> al=new ArrayList<Product>();
		String path=req.getServletPath();
		if(path.equals("/reqsearchproduct"))
		{
			System.out.println(p.getPname());
			String product=req.getParameter("t1");
			HttpSession  session=req.getSession();
			session.setAttribute("searchvalue", product);
			p.setPname(product);
			al=new Dao().searchProduct(p);
			System.out.println(p.getPname());
			req.setAttribute("products", al);
			if(al!=null)
			{
				File f=new File("D://cloud");
				File arr[]=f.listFiles();
				req.setAttribute("filenames", arr);
				RequestDispatcher rd=req.getRequestDispatcher("view/searchResult.jsp");
				rd.forward(req,res);
				
			}
			else
			{
				RequestDispatcher rd=req.getRequestDispatcher("view/searchResult.jsp");
				rd.forward(req,res);
			  	
			}
		}
		else if(path.equals("/reqsorting"))
		{
			
			String value=req.getParameter("value");  //lh or hl
			HttpSession session=req.getSession();
	           p.setPname(session.getAttribute("search").toString());
	           
	          al=new Dao().searchProduct(p);
	          req.setAttribute("products", al);  
	          if(al!=null)
				{
					File f=new File("D://cloud");
					File arr[]=f.listFiles();
					req.setAttribute("filenames", arr);         //  list of file names from cloud
					RequestDispatcher rd=req.getRequestDispatcher("view/searchResult.jsp");
					rd.forward(req,res);
					
				}
		}
		else if(path.equals("/reqaddtocart"))
		{
			Product p1=new Product();
			   p1.setPid(req.getParameter("pid"));
			
			   p1=new Dao().productInfoByPid(p1);
			   req.setAttribute("productinfo", p1);
			   File f=new File("D://cloud");
				File arr[]=f.listFiles();
				
				for(File f1:arr)
				{
				
					if(p1.getFilename().equals(f1.getName()))
							{
						
						          req.setAttribute("filename", f1);
						       RequestDispatcher rd=req.getRequestDispatcher("view/AddToCart.jsp");
						       rd.forward(req, res);
							}
				}
		}
		else if(path.equals("/addtocart1"))
		{
			PrintWriter out=res.getWriter();
			String id=null;
			Product p1=new Product();
			p1.setPname(req.getParameter("pname"));
			p1.setPprice(Double.parseDouble(req.getParameter("pprice")));
			p1.setPid(req.getParameter("pid"));
			p1.setPqty(Integer.parseInt(req.getParameter("pqty")));
			
			
			
			
			id=new Dao().addTOCart(p1);
			
			
			
			
			System.out.println(p.getPname());
			System.out.println(p.getPid());
			
			
			if(id!=null)
				
			{
				out.print(p1.getPname()+" details added to cart successfully. <a href=reqviewcart>View Cart</a>");
			}
			else
			{
				out.print("fail");
			}
		}
		else if(path.equals("/reqviewcart"))
		{
			ArrayList<Cart> cl=new ArrayList<Cart>();
			cl=new Dao().viewcart();
			req.setAttribute("cart", cl);
			 RequestDispatcher rd=req.getRequestDispatcher("view/viewcart.jsp");
			  rd.forward(req, res);
		}
		else if(path.equals("/reqpaybill"))
		{
			PrintWriter out=res.getWriter();
			Order o=new Order();
			o.setOamt(Double.parseDouble(req.getParameter("bill")));
			
			int i=new Dao().payBill(o);
			if(i>0)
			{
				out.print("Success");
			}
			else
			{
				out.print("fail");
			}
		}
	}
		public void doPost(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
		{

			boolean b=false;
			String path=req.getServletPath();
			if(path.equals("/reqcustomerlogin"))
			{
				Login l=new Login();
				l.setUname(req.getParameter("t1"));
				l.setPwd(req.getParameter("t2"));
				b=new Dao().customerLogin(l);
				if(b)
				{
					HttpSession session=req.getSession();
					session.setAttribute("clogin", l.getUname());
					RequestDispatcher rd=req.getRequestDispatcher("/addtocart1");
					rd.forward(req, res);
				}
			}
			
		}
		
		
	
}
