package model;

public class Cart
{
	private String pid,pname;

private double price,tprice;

public String getPid() {
	return pid;
}

public void setPid(String pid) {
	this.pid = pid;
}

public String getPname() {
	return pname;
}

public void setPname(String pname) {
	this.pname = pname;
}

public double getPrice() {
	return price;
}

public void setPrice(double price) {
	this.price = price;
}

public double getTprice() {
	return tprice;
}

public void setTprice(double tprice) {
	this.tprice = tprice;
}
}
