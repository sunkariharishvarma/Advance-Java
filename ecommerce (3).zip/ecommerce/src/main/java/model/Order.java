package model;

public class Order 
{
	private int oid;
	private double oamt;
	public int getOid() {
		return oid;
	}
	public void setOid(int oid) {
		this.oid = oid;
	}
	public double getOamt() {
		return oamt;
	}
	public void setOamt(double oamt) {
		this.oamt = oamt;
	}
}
