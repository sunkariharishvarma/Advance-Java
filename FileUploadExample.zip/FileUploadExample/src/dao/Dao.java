package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import model.Model1;

public class Dao 
{
	static Connection con=null;
	  public static Connection getConnectionObject()
	  {
		  try {
			  Class.forName("org.h2.Driver");
			  con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/hari","sa","sa");
		  }
		  catch(Exception e)
		  {
			  System.out.println(e);
		  }
		  
		  return con;
	  }
	  public boolean register(Model1 m)
	  {
		  boolean b=false;
		  con=Dao.getConnectionObject();
		  int i=0;
		  try {
			  PreparedStatement p=con.prepareStatement( "insert into file values(?,?,?,?)");
			  p.setString(1,m.getName());
			  p.setString( 2, m.getEmail());
			  p.setString( 3, m.getPhoto());
			  p.setLong( 4, m.getMobile());
			  i=p.executeUpdate();
			  if(i>0)
			  {
				  b=true;
			  }
		  }
		  
		  catch(Exception e)
		  {
			  System.out.println(e);
		  }
		return  b;
		  
	  }

}
