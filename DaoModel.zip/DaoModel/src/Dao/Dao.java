package Dao;
import java.sql.Statement;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


import Model.RegisterModel;

public class Dao 
{
	static Connection con=null;
	public  static Connection getConnectionObject() 
	{
		try {
			
			Class.forName("org.h2.Driver");
			con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/hari","sa","sa");	
		}
		catch(Exception e ) 
		{
			System.out.println(e);
			}
		return con;
		}
	public boolean register(RegisterModel rm)
	{
		boolean b=false;
		int i=0;
	con=Dao.getConnectionObject();
	try {
		  PreparedStatement pstmt=con.prepareStatement("insert into user1 values(?,?,?,?,?)");
		  pstmt.setString(1,rm.getName());
		  pstmt.setString(2,rm.getEmail());
		  pstmt.setString(3,rm.getPwd());
		  pstmt.setLong(4,rm.getMobile());
		  pstmt.setString(5,rm.getAddress());
		  i=pstmt.executeUpdate();
		  if(i>0)
		  {
			  b=true;
		  }
		  
		  }
		  catch(Exception e)
		  {
			  System.out.println(e);
		  }
		return b;
		}
	public ResultSet login(RegisterModel rm)
	    {
	      ResultSet rs=null;
	   con=Dao.getConnectionObject();
		  try 
		  {
			  Statement st=con.createStatement();
			   rs=st.executeQuery("select name,pwd from user1 where name='"+rm.getName()+"' and pwd='"+rm.getPwd()+"'");
		  }
		  catch(Exception e)
		  {
			  System.out.println(e);
		  }
		  return rs;
	   }
	public ResultSet viewAll(RegisterModel rm) 
	{
		ResultSet rs=null;

	con=Dao.getConnectionObject();
		  try 
		  {
			  Statement st=con.createStatement();
			   rs=st.executeQuery("select * from user1");
			   
		  }
		  catch(Exception e)
		  {
			  System.out.println(e);
		  }
		return rs;
		}
	public int Delete(RegisterModel rm)
	{
		int i=0;
		con=Dao.getConnectionObject();
		try{
			PreparedStatement pstmt=con.prepareStatement("delete form user1 where name='"+rm.getName()+"'");
		}
		catch(Exception e){System.out.println(e);
			
		}
		return i;
	}

	public int update(RegisterModel rm) 
	   {
		
		
		int i=0;
		con=Dao.getConnectionObject();
		try{
			String getAdr;
			PreparedStatement pstmt=con.prepareStatement("update user1 set email='"+rm.getEmail()+"',pwd='"+rm.getPwd()+"',mobile='"+rm.getMobile()+"',address='"+rm.getAddress()+"' from where name='"+rm.getName()+"'");                                          
		}
		catch(Exception e) {System.out.println(e);}
		return i;
		




	}

}
