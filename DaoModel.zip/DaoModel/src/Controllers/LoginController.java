package Controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Dao.Dao;

import Model.RegisterModel;
public class LoginController extends HttpServlet 
{
	public void service(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
	   {
		   PrintWriter out=res.getWriter();
		   RegisterModel rm=new RegisterModel();
		   rm.setName(req.getParameter("t1"));
		   rm.setPwd(req.getParameter("t2"));
		   ResultSet rs=null;
		   rs=new Dao().login(rm);
			    try
				   {
					if(rs.next())
					   {
						RequestDispatcher rd=req.getRequestDispatcher("welcome.html");
						rd.forward(req, res);
						
						   
					   }
					   else
					   {
						   RequestDispatcher rd=req.getRequestDispatcher("Login.html");
							rd.include(req, res);
							out.print("<center>Invalid username /password");
					   }
				   } 
				   catch (SQLException e) 
				   {

					System.out.println(e);
				}
	   }
}
