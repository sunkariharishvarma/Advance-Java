package Controllers;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Dao.Dao;
import Model.RegisterModel;
public class UpdateController extends HttpServlet
{

public void service(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException {
	
	PrintWriter out=res.getWriter();
	RegisterModel rm=new RegisterModel();
	rm.setName(req.getParameter("t1"));
	rm.setEmail(req.getParameter("t2"));
	rm.setPwd(req.getParameter("t3"));
	rm.setMobile(Long.parseLong(req.getParameter("t4")));
	rm.setAddress(req.getParameter("t5"));
	boolean b=new Dao().register(rm);

   if(b)
	{

    	RequestDispatcher rd=req.getRequestDispatcher("reqallusers");
    	rd.forward(req, res);
	}
	else
	{
		out.print("Update fail");
	}
	
	
	
}
	

}
