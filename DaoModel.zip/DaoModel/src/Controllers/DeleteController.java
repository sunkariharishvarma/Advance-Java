package Controllers;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;

import Dao.Dao;
import Model.RegisterModel;
public class DeleteController extends HttpServlet
{
	public void service (HttpServletRequest req,HttpServletResponse res) throws IOException
	{
		PrintWriter out=res.getWriter();
		RegisterModel rm=new RegisterModel();
		rm.setName(req.getParameter("t1"));
		int i=new Dao().Delete(rm);
		if(i>0)
		{
			out.print("deleted  successfully");
		}
		else 
		{ out.print("error ");
				}
		
	
		
	}

}
