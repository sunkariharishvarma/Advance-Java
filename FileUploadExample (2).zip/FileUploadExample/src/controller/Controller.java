package controller;

import java.io.File;
import java.util.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import dao.Dao;
import model.Model1;


@WebServlet("/reqreg")
public class Controller extends HttpServlet
{
	private final String upload_dir="D://cloud";
	public void doPost(HttpServletRequest req,HttpServletResponse res)
	{
		Model1 m=new Model1();
		if(ServletFileUpload.isMultipartContent(req))
		{
			try {
			List<FileItem> multiparts =new ServletFileUpload(new DiskFileItemFactory()).parseRequest(req);
			
				for(FileItem item : multiparts)
				{
					if(!item.isFormField())
					{
						String name=new File(item.getName()).getName();
						item.write(new File(upload_dir + File.separator +name));
						//System.out.println("Fname:"+name);
						m.setPhoto(name);
					}
					else
					{
						//System.out.println("Item value"+item.getString());
						if(item.getFieldName().equals("t1"))
						{
							m.setName(item.getString());
						}
						if(item.getFieldName().equals("t2"))
						{
							m.setEmail(item.getString());
						}
						
						if(item.getFieldName().equals("t4"))
						{
					m.setMobile( Long.parseLong(item.getString()));
						}
					}
					
				}
				new Dao().register(m);
				
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}	
	}
}
